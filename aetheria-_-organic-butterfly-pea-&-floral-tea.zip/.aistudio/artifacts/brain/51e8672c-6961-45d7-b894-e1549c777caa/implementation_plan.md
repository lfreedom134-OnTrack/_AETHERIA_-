# AETHERIA | Immersive Landing & Streamlined Brand Experience

Rebrand the storefront back to **AETHERIA**, expand the landing hero into a **grand full-width immersive banner** highlighting the first picture, simplify the top menu to **3 essential navigation options**, and remove all Chinese characters and previous *Mother Nature* branding across the entire application.

> [!IMPORTANT]
> **Confirmed User Decisions & Aesthetic Alignment**:
> - **Brand Wordmark**: Reverted back to **AETHERIA** in high-contrast serif typography across the header, packaging inscriptions, footer, and metadata; completely removed all *Mother Nature* branding.
> - **Top Menu Navigation**: Simplified strictly to **3 clean options**: `Tea shop`, `Tea guide`, `Our brand` (with shopping bag action on the right).
> - **Header Format**: Clean, minimalist single bar without the top announcement strip.
> - **Hero Layout**: Full-width immersive cinematic banner showcasing the first picture (`AETHERIA Butterfly Pea Flower Tea` box, porcelain teacup, and dried flowers) with elegant editorial text layered on top.
> - **Language Clean-up**: Removed all Chinese writing (such as `觀善茶`) across the landing page, realm cards, and product data, cleanly renaming the blend to **Imperial Gold Reserve**.

---

## 1. Overview & Core Concept

- **What It Does**: AETHERIA provides a luxury direct-to-consumer tea experience centered on the hypnotic beauty and wellness of organic butterfly pea flower tea. It combines an expansive, full-width visual hero with intuitive, distraction-free navigation.
- **Target Audience / Persona**: Design-conscious tea lovers and wellness enthusiasts seeking pure, single-origin butterfly pea infusions without marketing noise or cluttered navigation.
- **Key Value**: Immediate visual immersion upon landing, effortless navigation across 3 clear pathways, and authentic botanical storytelling.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Minimalist Top Navigation**:
   - Single clean row featuring **AETHERIA** wordmark, exactly 3 navigation links:
     - `Tea shop` → Smooth-scrolls to the Botanical Realms showcase and full tea catalog (`#products`)
     - `Tea guide` → Smooth-scrolls to the Color Alchemy lab and brewing ritual (`#brewing-ritual`)
     - `Our brand` → Smooth-scrolls to the ethical sourcing and whole-flower craftsmanship section (`#our-brand`)
   - Primary action: Shopping bag drawer toggle with real-time item counter.

2. **Full-Width Immersive Hero Landing (First Picture)**:
   - Expands the first picture (`/assets/aistudio/Gemini_Generated_Image__1__fdd46dd6.jpeg`) into a grand, full-bleed cinematic container.
   - Editorial typography layered gracefully over the hero with measured contrast scrims:
     - Title: *"The Living Indigo Bloom of Wild Herbal Tea"*
     - Natural pH chromatic transition indicator
     - High-intent primary CTAs: *"Acquire Signature Box — $24.00"* and *"Tasting Notes & Ritual"*
   - Removed artificial digital overlays on the box to let the original *AETHERIA* packaging shine naturally.

3. **Centerpiece Botanical Exhibition (Second Picture)**:
   - Preserves the interactive 5-Realm parallax column selector (Zen White, Imperial Gold Reserve, Wild Harvest, Royal Amethyst, Midnight Obsidian) with all Chinese characters cleanly eliminated.

4. **Interactive Alchemy & Catalog**:
   - Interactive pH Color Alchemy Lab (lemon drop simulation).
   - Filterable product catalog with quick preview and seamless bag drawer checkout.

### Visual Hierarchy & Palette

- **Canvas & Tone**: Deep indigo sapphire (`#10223D`), cobalt (`#1A3F9C`), luminous wildflower gold (`#D4AF37`), and soft warm alabaster (`#FAF8F5`).
- **Typography**: Expressive luxury serif (`Cormorant Garamond` / `Playfair Display`) paired with clean geometric body prose (`Plus Jakarta Sans`).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Full-Width Immersive Hero Treatment**:
  - *Chosen Approach*: Expand the hero container to full-width aspect ratio (`min-h-[88vh]`) with gradient scrims ensuring WCAG AA contrast (4.5:1+) for layered headlines and CTAs.
  - *Why*: Directly satisfies the user request to make the first picture big, creating immediate visual impact upon arrival.
- **Decision 2: 3-Link Minimalist Menu Bar**:
  - *Chosen Approach*: Condense navigation to `Tea shop`, `Tea guide`, and `Our brand`.
  - *Why*: Eliminates cognitive load, directing users straight into purchasing, brewing education, or brand heritage.
- **Decision 3: Complete Removal of Chinese Typography**:
  - *Chosen Approach*: Replace all occurrences of `觀善茶` and related characters in titles, metadata, badges, and image cards with `Imperial Gold Reserve`.
  - *Why*: Ensures a unified, cohesive English editorial aesthetic requested by the user.

---

## 4. Technical Architecture & Component Hierarchy

```
┌────────────────────────────────────────────────────────┐
│                   AETHERIA Storefront                  │
├────────────────────────────────────────────────────────┤
│  Minimalist Header (Brand: AETHERIA · 3 Links · Bag)   │
├────────────────────────────────────────────────────────┤
│  Full-Width Immersive Hero Banner (First Picture Big)  │
│  - Layered Editorial Typography & Quick Add CTA        │
│  - Natural pH Color-Shift Bar                          │
├────────────────────────────────────────────────────────┤
│  Middle Exhibition (Second Picture · 5 Parallax Realms)│
│  - Imperial Gold Reserve (Zero Chinese Characters)     │
├────────────────────────────────────────────────────────┤
│  Interactive Color Alchemy Lab (pH Lemon Infusion)     │
├────────────────────────────────────────────────────────┤
│  Tea Shop Catalog (All Realms & Moods)                 │
├────────────────────────────────────────────────────────┤
│  Tea Guide: Brewing Ritual & Steep Timer               │
├────────────────────────────────────────────────────────┤
│  Our Brand: Ethical Sourcing & Biodegradable Pyramids  │
├────────────────────────────────────────────────────────┤
│  Footer (AETHERIA Botanicals · Harvest Dispatch)       │
├────────────────────────────────────────────────────────┤
│  Slide-over Cart Drawer & Product Detail Modal         │
└────────────────────────────────────────────────────────┘
```

---

## 5. Verification & Testing Plan

1. **Unit Testing**:
   - Run `npx --yes tsx --test src/utils/cart.test.ts` to verify cart pricing, threshold calculations, and color shift transitions.
2. **Compilation**:
   - Run `compile_applet` to confirm clean TypeScript compilation.
3. **Visual Verification (Playwright)**:
   - Check desktop viewport (1440×900) ensuring the full-width hero banner renders without clipping or overflow.
   - Verify the 3-link menu bar (`Tea shop`, `Tea guide`, `Our brand`) and AETHERIA logo.
   - Confirm zero Chinese writing remains in DOM snapshots.
   - Verify mobile viewport (390×844) responsiveness.
