import React, { useState } from 'react';
import { Eye, Plus, Check, Star, ShieldCheck, Heart, Moon, Sparkles, Brain, Zap } from 'lucide-react';
import { TEA_PRODUCTS } from '../data/teaProducts';
import { TeaCategory, TeaProduct, WellnessBenefit } from '../types/tea';
import { CartItem, formatCurrency } from '../utils/cart';

interface ProductCatalogProps {
  onAddToCart: (item: CartItem) => void;
  onOpenQuickView: (productId: string) => void;
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  onAddToCart,
  onOpenQuickView,
}) => {
  const [filterMode, setFilterMode] = useState<'category' | 'wellness'>('wellness');
  const [selectedCategory, setSelectedCategory] = useState<TeaCategory>('all');
  const [selectedBenefit, setSelectedBenefit] = useState<WellnessBenefit>('all');
  const [addedIds, setAddedIds] = useState<{ [id: string]: boolean }>({});

  const wellnessFilters: { id: WellnessBenefit; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'All Wellness Goals', icon: <Heart className="w-3.5 h-3.5" /> },
    { id: 'sleep', label: 'Deep Sleep & Relaxation', icon: <Moon className="w-3.5 h-3.5 text-indigo-500" /> },
    { id: 'radiance', label: 'Skin Radiance & Antioxidants', icon: <Sparkles className="w-3.5 h-3.5 text-amber-500" /> },
    { id: 'clarity', label: 'Meditation & Focus', icon: <Brain className="w-3.5 h-3.5 text-blue-500" /> },
    { id: 'vitality', label: 'Vitality & Cold Extraction', icon: <Zap className="w-3.5 h-3.5 text-cyan-500" /> },
  ];

  const categories: { id: TeaCategory; label: string }[] = [
    { id: 'all', label: 'All Realms' },
    { id: 'signature', label: 'Signature Blue' },
    { id: 'zen', label: 'Zen & Imperial' },
    { id: 'wild', label: 'Wild & Herbal' },
    { id: 'twilight', label: 'Twilight Violet' },
    { id: 'modernist', label: 'Modernist Lab' },
  ];

  const filteredProducts = TEA_PRODUCTS.filter((p) => {
    if (filterMode === 'wellness') {
      return selectedBenefit === 'all' || p.wellnessBenefit === selectedBenefit;
    } else {
      return selectedCategory === 'all' || p.category === selectedCategory;
    }
  });

  const handleAdd = (product: TeaProduct) => {
    onAddToCart({
      id: product.id,
      name: product.name,
      subtitle: product.subtitle,
      price: product.price,
      quantity: 1,
      image: product.image,
      category: product.categoryName,
      weight: product.weight,
    });
    setAddedIds((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedIds((prev) => ({ ...prev, [product.id]: false }));
    }, 2000);
  };

  return (
    <section id="products" className="py-24 bg-[#F4EFE6]/50 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-[#1A3F9C] font-semibold mb-2">
              AETHERIA Herbal Apothecary
            </div>
            <h2
              className="font-serif text-3xl sm:text-4xl text-[#10223D] font-normal"
              style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
            >
              Curated by Health & Herbal Intent
            </h2>
          </div>

          {/* Toggle between Wellness Filter and Realm Categories */}
          <div className="flex items-center gap-1.5 p-1 bg-white rounded-xl border border-[#14233C]/10 shadow-xs self-start md:self-auto">
            <button
              onClick={() => setFilterMode('wellness')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                filterMode === 'wellness'
                  ? 'bg-[#10223D] text-white shadow-xs'
                  : 'text-[#14233C]/70 hover:text-[#10223D]'
              }`}
            >
              Wellness Intent
            </button>
            <button
              onClick={() => setFilterMode('category')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                filterMode === 'category'
                  ? 'bg-[#10223D] text-white shadow-xs'
                  : 'text-[#14233C]/70 hover:text-[#10223D]'
              }`}
            >
              Botanical Realm
            </button>
          </div>
        </div>

        {/* Filter Pills / Tabs Row */}
        <div className="mb-10 overflow-x-auto pb-2">
          <div className="inline-flex items-center gap-1.5 p-1.5 bg-white rounded-2xl border border-[#14233C]/10 shadow-xs">
            {filterMode === 'wellness'
              ? wellnessFilters.map((filter) => {
                  const active = selectedBenefit === filter.id;
                  return (
                    <button
                      key={filter.id}
                      onClick={() => setSelectedBenefit(filter.id)}
                      className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-xl transition-all whitespace-nowrap shrink-0 ${
                        active
                          ? 'bg-[#1A3F9C] text-white shadow-sm font-semibold'
                          : 'text-[#14233C]/70 hover:text-[#10223D] hover:bg-slate-50'
                      }`}
                    >
                      {filter.icon}
                      <span>{filter.label}</span>
                    </button>
                  );
                })
              : categories.map((cat) => {
                  const active = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-4 py-2 text-xs font-medium rounded-xl transition-all whitespace-nowrap shrink-0 ${
                        active
                          ? 'bg-[#10223D] text-white shadow-sm font-semibold'
                          : 'text-[#14233C]/70 hover:text-[#10223D] hover:bg-slate-50'
                      }`}
                    >
                      {cat.label}
                    </button>
                  );
                })}
          </div>
        </div>

        {/* 3-Column Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => {
            const isAdded = !!addedIds[product.id];
            return (
              <div
                key={product.id}
                className="group flex flex-col bg-white rounded-2xl border border-[#14233C]/8 overflow-hidden shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
              >
                {/* Product Image Stage (65-75% height) */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#FAF8F5] flex items-center justify-center p-2">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover rounded-xl transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />

                  {/* Rating indicator */}
                  <div className="absolute top-4 right-4 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-md shadow-xs border border-black/5 flex items-center gap-1 text-[11px] font-medium text-[#10223D]">
                    <Star className="w-3 h-3 text-[#D4AF37] fill-[#D4AF37]" />
                    <span className="tabular-nums">{product.rating.toFixed(1)}</span>
                    <span className="text-black/40">({product.reviewCount})</span>
                  </div>

                  {/* Bleach-Free Trust Tag in Buddha Teas style */}
                  <div className="absolute top-4 left-4 px-2.5 py-1 rounded-full bg-white/95 backdrop-blur-md shadow-xs border border-emerald-500/20 text-[#2E7D32] text-[10px] font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    <span>Bleach-Free</span>
                  </div>

                  {/* Wellness Intent Badge */}
                  <div className="absolute bottom-4 left-4 px-2.5 py-1 rounded-md bg-[#10223D]/85 backdrop-blur-md text-white text-[11px] font-medium tracking-wide">
                    {product.wellnessLabel}
                  </div>
                </div>

                {/* Card Content & Contiguous Metadata */}
                <div className="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <div className="flex items-center justify-between text-xs text-[#14233C]/60 mb-1.5 font-medium">
                      <span>{product.weight}</span>
                      <span className="text-[#2E7D32]">Zero Additives</span>
                    </div>

                    <h3
                      className="font-serif text-xl font-normal text-[#10223D] group-hover:text-[#1A3F9C] transition-colors mb-2"
                      style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
                    >
                      {product.name}
                    </h3>

                    <p className="text-xs text-[#14233C]/70 line-clamp-2 leading-relaxed mb-4">
                      {product.tagline}
                    </p>

                    {/* Single-Ingredient Highlight & Tasting Notes */}
                    <div className="space-y-2 mb-5">
                      {product.singleIngredient && (
                        <div className="text-[11px] text-[#1A3F9C] font-semibold">
                          ✦ Core Herb: {product.singleIngredient}
                        </div>
                      )}
                      <div className="flex flex-wrap gap-1.5">
                        {product.tastingNotes.slice(0, 3).map((note, idx) => (
                          <span
                            key={idx}
                            className="text-[11px] px-2 py-0.5 rounded-sm bg-[#FAF8F5] text-[#14233C]/75 border border-[#14233C]/8"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Price & Action Row */}
                  <div className="pt-4 border-t border-[#14233C]/8 flex items-center justify-between">
                    <div>
                      <span className="text-lg font-serif font-medium text-[#10223D] tabular-nums">
                        {formatCurrency(product.price)}
                      </span>
                      {product.originalPrice && (
                        <span className="ml-2 text-xs text-[#14233C]/40 line-through tabular-nums">
                          {formatCurrency(product.originalPrice)}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onOpenQuickView(product.id)}
                        className="p-2.5 text-[#14233C]/70 hover:text-[#10223D] hover:bg-black/5 rounded-lg border border-[#14233C]/10 transition-colors focus-visible:outline-2 focus-visible:outline-[#10223D]"
                        title="Quick View & Brewing Notes"
                        aria-label={`View details for ${product.name}`}
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleAdd(product)}
                        className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#10223D] hover:bg-[#1A3F9C] active:scale-95 transition-all rounded-lg shadow-xs focus-visible:outline-2 focus-visible:outline-[#1A3F9C]"
                        aria-label={`Add ${product.name} to bag`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
