import React, { useState } from 'react';
import { ArrowDown, Droplets, Check, Plus, Sparkles, ShieldCheck } from 'lucide-react';
import { HERO_IMAGE, TEA_PRODUCTS } from '../data/teaProducts';
import { CartItem, formatCurrency } from '../utils/cart';

interface HeroProps {
  onAddToCart: (item: CartItem) => void;
  onOpenQuickView: (productId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onAddToCart, onOpenQuickView }) => {
  const [isAdded, setIsAdded] = useState(false);
  const signatureProduct = TEA_PRODUCTS[0];

  const handleQuickAdd = () => {
    onAddToCart({
      id: signatureProduct.id,
      name: signatureProduct.name,
      subtitle: signatureProduct.subtitle,
      price: signatureProduct.price,
      quantity: 1,
      image: signatureProduct.image,
      category: signatureProduct.categoryName,
      weight: signatureProduct.weight,
    });
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <section className="relative min-h-[90vh] pt-24 pb-16 flex flex-col justify-center overflow-hidden">
      {/* Background ambient watercolor splashes */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-20 -left-20 w-[42rem] h-[42rem] rounded-full bg-gradient-to-br from-[#1A3F9C]/16 via-[#3B82F6]/10 to-transparent blur-3xl animate-watercolor-bleed" />
        <div className="absolute top-1/2 -right-24 w-[38rem] h-[38rem] rounded-full bg-gradient-to-bl from-[#7C3AED]/12 via-[#D4AF37]/10 to-transparent blur-3xl animate-watercolor-bleed [animation-delay:4s]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        
        {/* Grand Big Image Stage (Full-Width Immersive Banner) */}
        <div className="relative w-full rounded-3xl overflow-hidden shadow-2xl border border-[#14233C]/10 bg-[#0E1D33] min-h-[580px] lg:min-h-[660px] flex items-center">
          
          {/* Main First Picture (Big & Immersive) */}
          <img
            src={HERO_IMAGE}
            alt="Aetheria Butterfly Pea Flower Tea box with porcelain teacup of deep blue tea, dried whole flowers, tea sachets and lemon"
            className="absolute inset-0 w-full h-full object-cover object-center scale-[1.02] transform transition-transform duration-1000 ease-out hover:scale-105"
            referrerPolicy="no-referrer"
            loading="eager"
          />

          {/* Measured Contrast Scrim across the banner */}
          <div className="absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-[#0C1A2E]/92 via-[#0C1A2E]/65 to-transparent/20" />

          {/* Layered Editorial Content on top of the big picture */}
          <div className="relative z-10 max-w-xl p-6 sm:p-10 lg:p-12 text-white">
            
            {/* Clean unboxed metadata separator */}
            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs uppercase tracking-[0.2em] text-[#D4AF37] font-semibold mb-4">
              <span className="whitespace-nowrap">AETHERIA BOTANICALS</span>
              <span aria-hidden="true" className="text-white/40">·</span>
              <span className="whitespace-nowrap">Organic Clitoria Ternatea</span>
              <span aria-hidden="true" className="text-white/40">·</span>
              <span className="whitespace-nowrap text-emerald-400">Bleach-Free</span>
            </div>

            {/* Display Headline */}
            <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-normal leading-[1.08] tracking-tight text-white mb-5 text-balance">
              The Living Indigo Bloom of Wild Herbal Tea.
            </h1>

            {/* Body Copy */}
            <p className="text-sm sm:text-base text-white/85 font-light leading-relaxed mb-6 max-w-lg">
              Hand-harvested sun-dried <span className="text-white font-medium italic">Clitoria ternatea</span> blossoms. 
              Savor an ethereal, royal sapphire nectar rich in anthocyanins that transforms into twilight violet 
              with a single kiss of fresh citrus.
            </p>

            {/* Interactive Color Shift Swatch Preview */}
            <div className="p-3.5 rounded-xl bg-black/45 border border-white/15 backdrop-blur-md max-w-md mb-6 shadow-md">
              <div className="flex items-center justify-between text-xs text-white/80 mb-2 font-medium">
                <span className="flex items-center gap-1.5 text-white">
                  <Droplets className="w-3.5 h-3.5 text-[#38BDF8]" />
                  Natural pH Chromatic Transition
                </span>
                <span className="text-[11px] uppercase tracking-wider text-[#D4AF37]">Alchemical Shift</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2.5 rounded-full bg-gradient-to-r from-[#1A3F9C] via-[#6B3FA0] to-[#B8236B] shadow-inner" />
              </div>
              <div className="flex justify-between items-center text-[10px] text-white/60 mt-1.5 font-medium">
                <span>Pure Spring (pH 7.4)</span>
                <span>Gentle Citrus (pH 5.8)</span>
                <span>Fresh Lemon (pH 3.5)</span>
              </div>
            </div>

            {/* Call to Action Group */}
            <div className="flex flex-wrap items-center gap-3.5 mb-6">
              <button
                onClick={handleQuickAdd}
                className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold tracking-wider uppercase text-[#10223D] bg-[#D4AF37] hover:bg-[#E5C378] active:scale-[0.98] transition-all rounded-lg shadow-lg focus-visible:outline-2 focus-visible:outline-white"
              >
                {isAdded ? (
                  <>
                    <Check className="w-4 h-4 text-[#10223D]" />
                    <span>Added to Bag</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>Acquire Signature Box — {formatCurrency(signatureProduct.price)}</span>
                  </>
                )}
              </button>

              <button
                onClick={() => onOpenQuickView(signatureProduct.id)}
                className="inline-flex items-center gap-2 px-5 py-3.5 text-xs font-semibold tracking-wider uppercase text-white bg-white/15 hover:bg-white/25 border border-white/25 rounded-lg transition-colors backdrop-blur-xs focus-visible:outline-2 focus-visible:outline-white"
              >
                Tasting Notes & Ritual
              </button>
            </div>

            {/* Key trust badges */}
            <div className="flex flex-wrap items-center gap-5 text-xs text-white/75 pt-4 border-t border-white/15">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>20 Whole-Flower Bags</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                <span>Zero Caffeine & Antioxidant Rich</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>100% Biodegradable</span>
              </div>
            </div>

          </div>

          {/* Subtle Bottom Right Card Badge */}
          <div className="absolute bottom-5 right-5 hidden sm:block p-3 rounded-xl bg-black/60 backdrop-blur-md border border-white/15 text-right z-10">
            <p className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-semibold">
              ORIGINAL ARTISANAL BATCH
            </p>
            <p className="text-xs font-serif text-white/90">
              Aetheria Butterfly Pea Tea · 40g
            </p>
          </div>

        </div>

        {/* Scroll indicator prompt */}
        <div className="mt-8 flex justify-center">
          <a
            href="#the-botanical-realm"
            className="group inline-flex flex-col items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#14233C]/60 hover:text-[#10223D] transition-colors"
          >
            <span>Explore The Five Realms</span>
            <ArrowDown className="w-4 h-4 animate-bounce text-[#1A3F9C]" />
          </a>
        </div>
      </div>
    </section>
  );
};
