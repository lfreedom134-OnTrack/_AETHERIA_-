import React from 'react';
import { ShieldCheck, Sparkles, Leaf, Recycle } from 'lucide-react';

export const PurityPromiseStrip: React.FC = () => {
  return (
    <section className="py-12 bg-white border-y border-[#14233C]/8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Subtitle */}
        <div className="text-center mb-8">
          <span className="text-[11px] uppercase tracking-[0.25em] text-[#2E7D32] font-semibold block mb-1">
            The AETHERIA Purity Standard
          </span>
          <h2
            className="font-serif text-2xl sm:text-3xl text-[#10223D] font-normal"
            style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
          >
            Tea in Its Purest, Unadulterated Form
          </h2>
        </div>

        {/* 4 Buddha Teas-Inspired Purity Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#14233C]/8 flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-[#2E7D32] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-base font-semibold text-[#10223D] mb-1">
                100% Bleach-Free Bags
              </h3>
              <p className="text-xs text-[#14233C]/70 leading-relaxed">
                Oxygen-whitened without chlorine or harmful dioxins. Clean, compostable unbleached plant mesh.
              </p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#14233C]/8 flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-[#C59B27] flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-base font-semibold text-[#10223D] mb-1">
                Zero Added Flavors
              </h3>
              <p className="text-xs text-[#14233C]/70 leading-relaxed">
                No "natural flavorings" or chemical extracts. Every aromatic note stems directly from real whole petals.
              </p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#14233C]/8 flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#1A3F9C] flex items-center justify-center shrink-0">
              <Leaf className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-base font-semibold text-[#10223D] mb-1">
                Single-Origin Organic
              </h3>
              <p className="text-xs text-[#14233C]/70 leading-relaxed">
                Nourished by volcanic rains in pesticide-free highland soils for maximum antioxidant ternatin potency.
              </p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#14233C]/8 flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
              <Recycle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-base font-semibold text-[#10223D] mb-1">
                100% Recycled Cartons
              </h3>
              <p className="text-xs text-[#14233C]/70 leading-relaxed">
                Printed with plant-based soy inks on post-consumer recycled paperboard, kind to our planet.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
