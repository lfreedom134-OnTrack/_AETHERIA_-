import React, { useState } from 'react';
import { X, Plus, Minus, Check, Star, Droplets, Thermometer, Clock, ShieldCheck, Leaf } from 'lucide-react';
import { TEA_PRODUCTS } from '../data/teaProducts';
import { CartItem, formatCurrency } from '../utils/cart';

interface ProductDetailModalProps {
  productId: string | null;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  productId,
  onClose,
  onAddToCart,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);

  if (!productId) return null;
  const product = TEA_PRODUCTS.find((p) => p.id === productId);
  if (!product) return null;

  const handleAdd = () => {
    onAddToCart({
      id: product.id,
      name: product.name,
      subtitle: product.subtitle,
      price: product.price,
      quantity,
      image: product.image,
      category: product.categoryName,
      weight: product.weight,
    });
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-60 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6">
      <div className="bg-[#FAF8F5] rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-[#14233C]/10 relative animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-white/80 hover:bg-white text-[#10223D] shadow-sm border border-slate-200 transition-colors focus-visible:outline-2 focus-visible:outline-[#1A3F9C]"
          aria-label="Close product view"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12">
          
          {/* Image Stage (5 cols) */}
          <div className="md:col-span-5 bg-white p-6 flex flex-col justify-center items-center border-b md:border-b-0 md:border-r border-[#14233C]/8">
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden shadow-sm bg-[#FAF8F5]">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 px-2 py-1 rounded-md bg-[#10223D]/80 backdrop-blur-md text-white text-[10px] font-medium uppercase tracking-wider">
                {product.categoryName}
              </div>
              <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-md bg-white/95 text-[#2E7D32] text-[10px] font-semibold shadow-xs flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                <span>Bleach-Free</span>
              </div>
            </div>

            <div className="mt-4 w-full text-center">
              <div className="flex items-center justify-center gap-1 text-xs text-[#10223D]">
                <Star className="w-3.5 h-3.5 text-[#D4AF37] fill-[#D4AF37]" />
                <span className="font-semibold">{product.rating.toFixed(2)}</span>
                <span className="text-black/50">({product.reviewCount} verified reviews)</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">{product.weight} · {product.servings}</p>
            </div>
          </div>

          {/* Details & Purchasing Column (7 cols) */}
          <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#1A3F9C] font-semibold mb-1">
                <span>{product.categoryName}</span>
                <span>·</span>
                <span className="text-[#2E7D32]">100% Bleach-Free</span>
              </div>

              <h3
                className="font-serif text-2xl sm:text-3xl text-[#10223D] font-normal mb-1"
                style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
              >
                {product.name}
              </h3>
              <p className="text-xs text-[#14233C]/60 mb-3">{product.subtitle}</p>

              <div className="text-xl font-serif font-medium text-[#10223D] mb-4 tabular-nums">
                {formatCurrency(product.price)}
              </div>

              <p className="text-xs text-[#14233C]/75 leading-relaxed mb-4">
                {product.tagline}
              </p>

              {/* Buddha Teas Purity Trust Badges */}
              <div className="flex flex-wrap gap-2 mb-4">
                {product.purityBadges.map((badge, bIdx) => (
                  <span
                    key={bIdx}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#FAF8F5] border border-[#14233C]/10 text-[#14233C]/80 text-[11px] font-medium"
                  >
                    <Leaf className="w-3 h-3 text-[#2E7D32]" />
                    <span>{badge}</span>
                  </span>
                ))}
              </div>

              {/* Flavor Profile Bars */}
              <div className="p-3.5 rounded-xl bg-white border border-[#14233C]/8 mb-5 space-y-2">
                <div className="text-[11px] uppercase tracking-wider font-semibold text-[#10223D] mb-1">
                  Botanical Flavor Metrics
                </div>

                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between items-center text-slate-600">
                    <span>Floral Intensity</span>
                    <span className="font-mono">{product.tasteProfile.floral}%</span>
                  </div>
                  <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#1A3F9C] rounded-full"
                      style={{ width: `${product.tasteProfile.floral}%` }}
                    />
                  </div>

                  <div className="flex justify-between items-center text-slate-600">
                    <span>Earth & Tannin</span>
                    <span className="font-mono">{product.tasteProfile.earthy}%</span>
                  </div>
                  <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#A05C38] rounded-full"
                      style={{ width: `${product.tasteProfile.earthy}%` }}
                    />
                  </div>

                  <div className="flex justify-between items-center text-slate-600">
                    <span>Anthocyanin Color Shift</span>
                    <span className="font-mono">{product.tasteProfile.citrusShift}%</span>
                  </div>
                  <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#1A3F9C] to-[#B8236B] rounded-full"
                      style={{ width: `${product.tasteProfile.citrusShift}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Brewing Spec Snapshot */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs p-3 rounded-xl bg-white border border-[#14233C]/8 mb-5">
                <div>
                  <Thermometer className="w-3.5 h-3.5 mx-auto text-[#1A3F9C] mb-1" />
                  <span className="block text-[10px] text-slate-500 uppercase">Temp</span>
                  <span className="font-semibold text-[11px] text-[#10223D]">{product.brewGuide.temp.split('(')[0]}</span>
                </div>
                <div>
                  <Clock className="w-3.5 h-3.5 mx-auto text-[#D4AF37] mb-1" />
                  <span className="block text-[10px] text-slate-500 uppercase">Steep</span>
                  <span className="font-semibold text-[11px] text-[#10223D]">{product.brewGuide.time}</span>
                </div>
                <div>
                  <Droplets className="w-3.5 h-3.5 mx-auto text-emerald-600 mb-1" />
                  <span className="block text-[10px] text-slate-500 uppercase">Water</span>
                  <span className="font-semibold text-[11px] text-[#10223D]">Spring</span>
                </div>
              </div>
            </div>

            {/* Purchasing Action Module */}
            <div className="pt-4 border-t border-[#14233C]/8 flex items-center gap-3">
              <div className="flex items-center border border-[#14233C]/15 rounded-lg overflow-hidden bg-white">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-2.5 py-2 text-xs hover:bg-slate-100"
                  aria-label="Decrease quantity"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="px-3 text-xs font-semibold tabular-nums text-[#10223D]">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-2.5 py-2 text-xs hover:bg-slate-100"
                  aria-label="Increase quantity"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                onClick={handleAdd}
                className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-[#10223D] hover:bg-[#1A3F9C] active:scale-95 transition-all rounded-lg shadow-sm"
              >
                {isAdded ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Added to Bag</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>Add to Bag — {formatCurrency(product.price * quantity)}</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
