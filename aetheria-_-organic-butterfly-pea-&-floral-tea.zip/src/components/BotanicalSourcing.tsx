import React from 'react';
import { ShieldCheck, HeartHandshake, Leaf, Droplet } from 'lucide-react';

export const BotanicalSourcing: React.FC = () => {
  return (
    <section id="our-brand" className="py-24 bg-white border-t border-[#14233C]/8 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="text-xs uppercase tracking-[0.2em] text-[#2E7D32] font-semibold mb-3">
            Pure Soil · Bleach-Free Heritage
          </div>
          <h2
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#10223D] mb-4"
            style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
          >
            AETHERIA Purity & Earth-Minded Alchemy
          </h2>
          <p className="text-sm sm:text-base text-[#14233C]/75 font-light leading-relaxed">
            Every petal of our <em>Clitoria ternatea</em> is harvested at dawn in pesticide-free volcanic soils, protected in chlorine-free unbleached sachets.
          </p>
        </div>

        {/* 4 Pillars of Excellence */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#14233C]/8 flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-[#2E7D32] flex items-center justify-center mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl text-[#10223D] font-normal mb-2">
                100% Bleach-Free Bags
              </h3>
              <p className="text-xs text-[#14233C]/70 leading-relaxed">
                Oxygen-whitened without chlorine or toxic dioxins. 100% compostable plant mesh with unbleached cotton string.
              </p>
            </div>
            <div className="mt-4 pt-4 border-t border-[#14233C]/8 text-[11px] font-semibold text-[#2E7D32]">
              Chlorine & Dioxin Free
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#14233C]/8 flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-blue-100 text-[#1A3F9C] flex items-center justify-center mb-4">
                <Leaf className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl text-[#10223D] font-normal mb-2">
                Zero Added Flavors
              </h3>
              <p className="text-xs text-[#14233C]/70 leading-relaxed">
                No "natural flavorings" or chemical extracts. Only pure, unadulterated whole botanicals and flowers.
              </p>
            </div>
            <div className="mt-4 pt-4 border-t border-[#14233C]/8 text-[11px] font-semibold text-[#1A3F9C]">
              100% Real Herbs Only
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#14233C]/8 flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-amber-100 text-[#C59B27] flex items-center justify-center mb-4">
                <HeartHandshake className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl text-[#10223D] font-normal mb-2">
                Direct Farmer Heritage
              </h3>
              <p className="text-xs text-[#14233C]/70 leading-relaxed">
                We partner with generational family herbal gardens, paying 45% above Fair Trade minimums directly to harvesters.
              </p>
            </div>
            <div className="mt-4 pt-4 border-t border-[#14233C]/8 text-[11px] font-semibold text-[#C59B27]">
              Fair Harvest Transparency
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#14233C]/8 flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-purple-100 text-[#5B21B6] flex items-center justify-center mb-4">
                <Droplet className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl text-[#10223D] font-normal mb-2">
                Whole-Flower Potency
              </h3>
              <p className="text-xs text-[#14233C]/70 leading-relaxed">
                Intact dried corollas protect fragile flavonoids until hot water unlocks radiant proanthocyanidins in your cup.
              </p>
            </div>
            <div className="mt-4 pt-4 border-t border-[#14233C]/8 text-[11px] font-semibold text-[#5B21B6]">
              Retains Natural Ternatins
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
