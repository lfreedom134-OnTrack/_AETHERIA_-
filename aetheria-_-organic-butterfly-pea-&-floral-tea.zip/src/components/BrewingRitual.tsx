import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Flame, Clock, Droplets, Sparkles, CheckCircle2 } from 'lucide-react';

export const BrewingRitual: React.FC = () => {
  const [secondsLeft, setSecondsLeft] = useState(300); // 5 minutes default
  const [timerRunning, setTimerRunning] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<'hot' | 'cold' | 'latte'>('hot');

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timerRunning && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (secondsLeft === 0) {
      setTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [timerRunning, secondsLeft]);

  const toggleTimer = () => setTimerRunning(!timerRunning);
  
  const resetTimer = (sec = 300) => {
    setTimerRunning(false);
    setSecondsLeft(sec);
  };

  const handleSelectMethod = (method: 'hot' | 'cold' | 'latte') => {
    setSelectedMethod(method);
    if (method === 'hot') resetTimer(300); // 5 min
    if (method === 'cold') resetTimer(7200); // 2 hours quick cold steep
    if (method === 'latte') resetTimer(360); // 6 min concentrated
  };

  const minutes = Math.floor(secondsLeft / 60);
  const remainingSeconds = secondsLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;

  return (
    <section id="brewing-ritual" className="py-24 bg-[#FAF8F5] border-t border-[#14233C]/8 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <div className="text-xs uppercase tracking-[0.2em] text-[#1A3F9C] font-semibold mb-3">
            Mindful Tea Ceremony
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-[#10223D] mb-4">
            The Botanical Brewing Ritual
          </h2>
          <p className="text-sm sm:text-base text-[#14233C]/75 font-light leading-relaxed">
            Unlocking the purest anthocyanin color and sweet floral notes requires temperature mindfulness and patience.
          </p>
        </div>

        {/* Brewing Method Selector Tabs */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex p-1 bg-white rounded-xl border border-[#14233C]/10 shadow-xs">
            <button
              onClick={() => handleSelectMethod('hot')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors ${
                selectedMethod === 'hot'
                  ? 'bg-[#10223D] text-white shadow-xs'
                  : 'text-[#14233C]/70 hover:text-[#10223D]'
              }`}
            >
              Ceremonial Hot Infusion
            </button>
            <button
              onClick={() => handleSelectMethod('cold')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors ${
                selectedMethod === 'cold'
                  ? 'bg-[#10223D] text-white shadow-xs'
                  : 'text-[#14233C]/70 hover:text-[#10223D]'
              }`}
            >
              Cold-Drip Indigo Elixir
            </button>
            <button
              onClick={() => handleSelectMethod('latte')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors ${
                selectedMethod === 'latte'
                  ? 'bg-[#10223D] text-white shadow-xs'
                  : 'text-[#14233C]/70 hover:text-[#10223D]'
              }`}
            >
              Velvet Butterfly Tea Latte
            </button>
          </div>
        </div>

        {/* 3 Steps + Interactive Timer Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Steps Column (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            
            <div className="p-5 bg-white rounded-2xl border border-[#14233C]/8 flex items-start gap-4 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-[#1A3F9C]/10 text-[#1A3F9C] flex items-center justify-center shrink-0 mt-0.5">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 text-xs text-[#1A3F9C] uppercase tracking-wider font-semibold mb-1">
                  <span>Step 01</span>
                  <span>·</span>
                  <span>Thermal Balance</span>
                </div>
                <h4 className="font-serif text-lg text-[#10223D] font-medium mb-1">
                  {selectedMethod === 'hot'
                    ? 'Heat Filtered Spring Water to 90°C (195°F)'
                    : selectedMethod === 'cold'
                    ? 'Prepare Chilled Alkaline Spring Water with Craft Ice'
                    : 'Brew 100ml Concentrated Hot Infusion at 95°C'}
                </h4>
                <p className="text-xs text-[#14233C]/70 leading-relaxed">
                  Avoid harsh boiling water to protect delicate floral aromatics and maintain bright sapphire clarity.
                </p>
              </div>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-[#14233C]/8 flex items-start gap-4 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/15 text-[#C59B27] flex items-center justify-center shrink-0 mt-0.5">
                <Droplets className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 text-xs text-[#C59B27] uppercase tracking-wider font-semibold mb-1">
                  <span>Step 02</span>
                  <span>·</span>
                  <span>Flower Awakening</span>
                </div>
                <h4 className="font-serif text-lg text-[#10223D] font-medium mb-1">
                  Submerge 1 Pyramid Sachet or 5-7 Whole Blossoms
                </h4>
                <p className="text-xs text-[#14233C]/70 leading-relaxed">
                  Watch cobalt ribbons unfurl gracefully through the water, releasing natural earthy sweetness.
                </p>
              </div>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-[#14233C]/8 flex items-start gap-4 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-[#5B21B6]/10 text-[#5B21B6] flex items-center justify-center shrink-0 mt-0.5">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 text-xs text-[#5B21B6] uppercase tracking-wider font-semibold mb-1">
                  <span>Step 03</span>
                  <span>·</span>
                  <span>The Alchemical Finishing Touch</span>
                </div>
                <h4 className="font-serif text-lg text-[#10223D] font-medium mb-1">
                  {selectedMethod === 'latte'
                    ? 'Froth Oat or Almond Milk and Layer Over Blue Infusion'
                    : 'Gently add 3-5 drops of Lemon or Lime'}
                </h4>
                <p className="text-xs text-[#14233C]/70 leading-relaxed">
                  Marvel as the infusion transforms into majestic purple and fuchsia before your eyes.
                </p>
              </div>
            </div>

          </div>

          {/* Interactive Steeping Timer Card (5 cols) */}
          <div className="lg:col-span-5 bg-[#10223D] rounded-3xl p-8 text-white text-center shadow-xl relative overflow-hidden">
            <div className="absolute -top-16 -right-16 w-36 h-36 rounded-full bg-[#1A3F9C]/40 blur-2xl pointer-events-none" />
            <div className="absolute -bottom-16 -left-16 w-36 h-36 rounded-full bg-[#D4AF37]/20 blur-2xl pointer-events-none" />

            <div className="relative z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs font-mono text-[#D4AF37] mb-6">
                <Clock className="w-3.5 h-3.5" />
                <span>Steep Timer</span>
              </div>

              {/* Big Digital Countdown */}
              <div className="font-mono text-5xl sm:text-6xl font-light tracking-wider my-4 tabular-nums text-white">
                {formattedTime}
              </div>

              <p className="text-xs text-white/70 mb-8">
                {secondsLeft === 0
                  ? 'Your infusion is perfectly steeped! Enjoy your tea.'
                  : timerRunning
                  ? 'Infusing delicate petals in filtered water...'
                  : 'Press start when water touches the tea leaves.'}
              </p>

              {/* Timer Controls */}
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={toggleTimer}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#D4AF37] hover:bg-[#E5C378] text-[#10223D] font-semibold text-xs uppercase tracking-wider transition-all active:scale-95 shadow-md focus-visible:outline-2 focus-visible:outline-white"
                >
                  {timerRunning ? (
                    <>
                      <Pause className="w-4 h-4" />
                      <span>Pause</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-current" />
                      <span>Start Timer</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => resetTimer(selectedMethod === 'hot' ? 300 : selectedMethod === 'cold' ? 7200 : 360)}
                  className="p-3 rounded-xl bg-white/10 hover:bg-white/15 text-white/80 hover:text-white transition-colors focus-visible:outline-2 focus-visible:outline-white"
                  title="Reset Timer"
                  aria-label="Reset Timer"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
