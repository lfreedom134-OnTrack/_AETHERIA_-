import React, { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X } from 'lucide-react';
import { CartItem } from '../utils/cart';

interface HeaderProps {
  cartItems: CartItem[];
  onOpenCart: () => void;
}

export const Header: React.FC<HeaderProps> = ({ cartItems, onOpenCart }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const totalItemCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAF8F5]/95 backdrop-blur-md shadow-xs border-b border-[#14233C]/10 py-3.5'
          : 'bg-transparent py-5 sm:py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Bar 3-Zone Contract: Brand — Exactly 3 Nav Links — 1 Primary Action */}
        <div className="flex items-center justify-between gap-8">
          
          {/* Zone 1: Wordmark AETHERIA */}
          <a
            href="#"
            className="group flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#1A3F9C]"
          >
            <span
              className="font-serif text-2xl sm:text-3xl font-normal tracking-[0.22em] text-[#10223D] group-hover:text-[#1A3F9C] transition-colors"
              style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
            >
              AETHERIA
            </span>
          </a>

          {/* Zone 2: Exactly 3 clean single-line text links */}
          <nav className="hidden md:flex items-center gap-10 text-xs font-medium uppercase tracking-[0.18em] text-[#14233C]/80">
            <a
              href="#products"
              className="hover:text-[#10223D] transition-colors hover:underline underline-offset-8 decoration-[#1A3F9C]/50 whitespace-nowrap shrink-0"
            >
              Tea shop
            </a>
            <a
              href="#brewing-ritual"
              className="hover:text-[#10223D] transition-colors hover:underline underline-offset-8 decoration-[#1A3F9C]/50 whitespace-nowrap shrink-0"
            >
              Tea guide
            </a>
            <a
              href="#our-brand"
              className="hover:text-[#10223D] transition-colors hover:underline underline-offset-8 decoration-[#1A3F9C]/50 whitespace-nowrap shrink-0"
            >
              Our brand
            </a>
          </nav>

          {/* Zone 3: 1 Primary Action (Bag trigger) */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenCart}
              aria-label={`Shopping bag containing ${totalItemCount} items`}
              className="relative inline-flex items-center gap-2 px-4 py-2 text-xs font-medium tracking-wider uppercase text-white bg-[#10223D] rounded-lg hover:bg-[#1A3F9C] active:scale-95 transition-all shadow-sm focus-visible:outline-2 focus-visible:outline-[#1A3F9C]"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Bag</span>
              <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 text-[11px] font-semibold bg-[#D4AF37] text-[#10223D] rounded-full tabular-nums">
                {totalItemCount}
              </span>
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#10223D] hover:bg-black/5 rounded-lg focus-visible:outline-2 focus-visible:outline-[#1A3F9C]"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-3 p-4 bg-[#FAF8F5] border border-[#14233C]/10 rounded-xl shadow-lg">
            <nav className="flex flex-col gap-3 text-sm font-medium tracking-wider uppercase text-[#14233C]">
              <a
                href="#products"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1 hover:text-[#1A3F9C]"
              >
                Tea shop
              </a>
              <a
                href="#brewing-ritual"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1 hover:text-[#1A3F9C]"
              >
                Tea guide
              </a>
              <a
                href="#our-brand"
                onClick={() => setMobileMenuOpen(false)}
                className="py-1 hover:text-[#1A3F9C]"
              >
                Our brand
              </a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};
