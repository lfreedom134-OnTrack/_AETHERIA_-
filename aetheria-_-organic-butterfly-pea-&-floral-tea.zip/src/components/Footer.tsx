import React, { useState } from 'react';
import { CheckCircle2, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setEmail('');
  };

  return (
    <footer className="bg-[#10223D] text-white pt-16 pb-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand & Editorial Column (4 cols) */}
          <div className="md:col-span-4">
            <span
              className="font-serif text-2xl sm:text-3xl font-normal tracking-[0.22em] text-white block mb-3"
              style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
            >
              AETHERIA
            </span>
            <p className="text-xs text-white/70 leading-relaxed max-w-sm mb-6">
              Purveyors of organic, single-origin butterfly pea flower and biodynamic herbal infusions. 
              Protected in 100% bleach-free tea bags with zero artificial flavors.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-[#D4AF37] uppercase tracking-wider font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-[#2E7D32]" />
              <span>100% Bleach-Free · USDA Organic · Clitoria Ternatea</span>
            </div>
          </div>

          {/* Navigation Links (4 cols) */}
          <div className="md:col-span-4 grid grid-cols-2 gap-6 text-xs text-white/70">
            <div>
              <p className="text-white font-medium uppercase tracking-wider text-[11px] mb-3">
                The Five Realms
              </p>
              <ul className="space-y-2">
                <li><a href="#the-botanical-realm" className="hover:text-white transition-colors">Pure Zen Series</a></li>
                <li><a href="#the-botanical-realm" className="hover:text-white transition-colors">Imperial Gold Reserve</a></li>
                <li><a href="#the-botanical-realm" className="hover:text-white transition-colors">Wild Herbal Harvest</a></li>
                <li><a href="#the-botanical-realm" className="hover:text-white transition-colors">Royal Amethyst Twilight</a></li>
                <li><a href="#the-botanical-realm" className="hover:text-white transition-colors">Midnight Obsidian Lab</a></li>
              </ul>
            </div>
            <div>
              <p className="text-white font-medium uppercase tracking-wider text-[11px] mb-3">
                Tea Guide & Heritage
              </p>
              <ul className="space-y-2">
                <li><a href="#products" className="hover:text-white transition-colors">Tea Shop Catalog</a></li>
                <li><a href="#brewing-ritual" className="hover:text-white transition-colors">Brewing Rituals & Timer</a></li>
                <li><a href="#color-alchemy" className="hover:text-white transition-colors">Anthocyanin Color Science</a></li>
                <li><a href="#our-brand" className="hover:text-white transition-colors">Our Brand & Sourcing</a></li>
                <li><a href="#our-brand" className="hover:text-white transition-colors">100% Bleach-Free Bags</a></li>
              </ul>
            </div>
          </div>

          {/* Newsletter Column (4 cols) */}
          <div className="md:col-span-4">
            <p className="text-white font-medium uppercase tracking-wider text-[11px] mb-2">
              The Harvest Dispatch
            </p>
            <p className="text-xs text-white/70 leading-relaxed mb-4">
              Join our botanical community to receive seasonal harvest bulletins, private batch allocations, and pure wellness recipes.
            </p>

            {subscribed ? (
              <div className="flex items-center gap-2 p-3 bg-white/10 rounded-lg text-xs text-[#D4AF37]">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                <span>You are enrolled in the Harvest Dispatch.</span>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex gap-2">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="flex-1 px-3.5 py-2.5 text-xs bg-white/10 border border-white/15 rounded-lg text-white placeholder:text-white/40 focus:outline-[#D4AF37]"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#D4AF37] hover:bg-[#E5C378] text-[#10223D] rounded-lg transition-colors shrink-0"
                >
                  Join
                </button>
              </form>
            )}
          </div>

        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-white/50 gap-4">
          <p>© {new Date().getFullYear()} AETHERIA Botanicals. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-white transition-colors cursor-pointer">Privacy Policy</span>
            <span className="hover:text-white transition-colors cursor-pointer">Terms of Service</span>
            <span className="hover:text-white transition-colors cursor-pointer">Shipping & Returns</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
