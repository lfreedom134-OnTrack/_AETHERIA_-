import React, { useState } from 'react';
import { Droplet, Sparkles, RefreshCw, Plus, Check, Info } from 'lucide-react';
import { calculateColorShift, CartItem, formatCurrency } from '../utils/cart';
import { TEA_PRODUCTS } from '../data/teaProducts';

interface ColorAlchemySectionProps {
  onAddToCart: (item: CartItem) => void;
}

export const ColorAlchemySection: React.FC<ColorAlchemySectionProps> = ({ onAddToCart }) => {
  const [ph, setPh] = useState(7.4);
  const [lemonDrops, setLemonDrops] = useState(0);
  const [isAdded, setIsAdded] = useState(false);

  const currentShift = calculateColorShift(ph);
  const signatureProduct = TEA_PRODUCTS[0];

  const handleAddDrop = () => {
    if (lemonDrops >= 6) {
      // Reset
      setLemonDrops(0);
      setPh(7.4);
      return;
    }
    const newDrops = lemonDrops + 1;
    setLemonDrops(newDrops);
    // Decrease pH as drops increase
    const newPh = Math.max(3.2, 7.4 - newDrops * 0.7);
    setPh(Math.round(newPh * 10) / 10);
  };

  const handleReset = () => {
    setLemonDrops(0);
    setPh(7.4);
  };

  const handleAddToCart = () => {
    onAddToCart({
      id: signatureProduct.id,
      name: signatureProduct.name,
      subtitle: signatureProduct.subtitle,
      price: signatureProduct.price,
      quantity: 1,
      image: signatureProduct.image,
      category: signatureProduct.categoryName,
      weight: signatureProduct.weight,
    });
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <section id="color-alchemy" className="relative py-24 bg-[#FAF8F5] overflow-hidden scroll-mt-16">
      {/* Background watercolor blooming ring */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[42rem] h-[42rem] rounded-full blur-3xl opacity-25 pointer-events-none transition-colors duration-700"
        style={{ backgroundColor: currentShift.hexColor }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
        
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#1A3F9C] font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Interactive Laboratory</span>
            <span aria-hidden="true">·</span>
            <span>Anthocyanin Ternatin</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal tracking-tight text-[#10223D] mb-4">
            The Living Color Alchemical Shift
          </h2>
          <p className="text-sm sm:text-base text-[#14233C]/75 leading-relaxed font-light">
            Clitoria ternatea contains extraordinary polyphenolic anthocyanins called <em>ternatins</em>. 
            Add fresh lemon drops below to observe how acidity transforms natural sapphire blue into violet and vivid magenta.
          </p>
        </div>

        {/* Interactive Experiment Container */}
        <div className="max-w-4xl mx-auto bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-[#14233C]/8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            
            {/* Visual Alchemy Flask / Cup representation */}
            <div className="md:col-span-6 flex flex-col items-center justify-center p-6 bg-[#F8F9FA] rounded-2xl border border-slate-100">
              <div className="relative w-56 h-56 sm:w-64 sm:h-64 flex items-center justify-center">
                
                {/* Glowing fluid aura */}
                <div
                  className="absolute inset-4 rounded-full blur-xl transition-all duration-700"
                  style={{ backgroundColor: currentShift.glowColor }}
                />

                {/* Porcelain saucer / golden rim simulation */}
                <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full border-4 border-[#D4AF37]/40 bg-white shadow-2xl p-3 flex items-center justify-center">
                  
                  {/* Swirling tea liquid */}
                  <div
                    className="w-full h-full rounded-full transition-all duration-700 relative overflow-hidden flex items-center justify-center shadow-inner"
                    style={{
                      background: `radial-gradient(circle at 35% 35%, ${currentShift.hexColor} 0%, #0F172A 95%)`,
                    }}
                  >
                    {/* Ripples & reflection highlights */}
                    <div className="absolute inset-3 rounded-full border border-white/20 animate-spin [animation-duration:24s]" />
                    <div className="absolute inset-8 rounded-full border border-white/15 animate-spin [animation-duration:16s] [animation-direction:reverse]" />
                    
                    {/* Lemon slice floating when citrus added */}
                    {lemonDrops > 0 && (
                      <div className="absolute top-6 right-6 w-10 h-10 rounded-full bg-yellow-300/80 border-2 border-yellow-200/90 shadow-md flex items-center justify-center animate-petal-drift">
                        <div className="w-8 h-8 rounded-full border border-yellow-500/30 flex items-center justify-center">
                          <span className="text-[9px] font-bold text-yellow-900">🍋</span>
                        </div>
                      </div>
                    )}

                    <div className="text-center z-10 px-3">
                      <p className="text-xs uppercase tracking-widest font-serif text-white/90 drop-shadow-md">
                        {currentShift.colorName}
                      </p>
                      <p className="text-[11px] font-mono text-white/70 mt-0.5">
                        pH {ph.toFixed(1)}
                      </p>
                    </div>
                  </div>
                </div>

              </div>

              {/* Status pill under flask */}
              <div className="mt-4 text-center">
                <span className="text-xs font-medium text-[#10223D]">
                  {lemonDrops === 0
                    ? 'Pure filtered spring water'
                    : `${lemonDrops} drop${lemonDrops > 1 ? 's' : ''} of fresh lemon juice infused`}
                </span>
              </div>
            </div>

            {/* Interactive Controls & Alchemy Explanation */}
            <div className="md:col-span-6 flex flex-col justify-center">
              
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#10223D]">
                    Infusion Acidity Index (pH)
                  </span>
                  <span className="font-mono text-sm font-bold text-[#1A3F9C] tabular-nums">
                    pH {ph.toFixed(1)}
                  </span>
                </div>

                {/* pH Slider */}
                <input
                  type="range"
                  min="3.2"
                  max="7.8"
                  step="0.1"
                  value={ph}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setPh(val);
                    const drops = Math.max(0, Math.min(6, Math.round((7.4 - val) / 0.7)));
                    setLemonDrops(drops);
                  }}
                  className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#1A3F9C]"
                  aria-label="Infusion pH level control"
                />

                <div className="flex justify-between text-[11px] text-[#14233C]/60 mt-2 font-mono">
                  <span>pH 3.2 (Acidic / Magenta)</span>
                  <span>pH 5.5 (Violet)</span>
                  <span>pH 7.8 (Alkaline / Cobalt)</span>
                </div>
              </div>

              {/* Dynamic Description Box */}
              <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#14233C]/10 mb-6">
                <div className="flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-[#1A3F9C] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#10223D] mb-1">
                      {currentShift.colorName} State
                    </h4>
                    <p className="text-xs text-[#14233C]/75 leading-relaxed">
                      {currentShift.description}
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Buttons: Add Drop & Reset */}
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={handleAddDrop}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#1A3F9C] hover:bg-[#10223D] active:scale-95 transition-all rounded-lg shadow-sm focus-visible:outline-2 focus-visible:outline-[#1A3F9C]"
                >
                  <Droplet className="w-4 h-4 text-yellow-300" />
                  <span>
                    {lemonDrops >= 6 ? 'Reset to Pure Blue' : 'Squeeze Lemon Droplet'}
                  </span>
                </button>

                <button
                  onClick={handleReset}
                  className="p-3 text-[#14233C]/70 hover:text-[#10223D] hover:bg-black/5 border border-[#14233C]/15 rounded-lg transition-colors focus-visible:outline-2 focus-visible:outline-[#10223D]"
                  title="Reset to default infusion"
                  aria-label="Reset infusion"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>

              {/* Direct Add Product Prompt */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-[#10223D]">Experience this at home</p>
                  <p className="text-xs text-[#14233C]/60">20 Bleach-Free Whole-Flower Pyramids · {formatCurrency(signatureProduct.price)}</p>
                </div>
                <button
                  onClick={handleAddToCart}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#10223D] bg-amber-50 hover:bg-amber-100 border border-amber-200/80 rounded-lg transition-colors"
                >
                  {isAdded ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>In Bag</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add to Bag</span>
                    </>
                  )}
                </button>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
