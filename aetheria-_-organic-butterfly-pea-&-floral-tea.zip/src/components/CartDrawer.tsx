import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, CheckCircle2, ShieldCheck, Tag } from 'lucide-react';
import { CartItem, calculateCartTotals, formatCurrency, FREE_SHIPPING_THRESHOLD } from '../utils/cart';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoMessage, setPromoMessage] = useState<string | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutComplete, setCheckoutComplete] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  // Form states
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');

  const totals = calculateCartTotals(items, discountPercent);

  const applyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = promoCode.trim().toUpperCase();
    if (clean === 'ALCHEMIST10' || clean === 'BLOOM10' || clean === 'AETHERIA') {
      setDiscountPercent(10);
      setPromoMessage('10% Botanical discount applied!');
    } else {
      setPromoMessage('Invalid promo code. Try "BLOOM10"');
    }
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail || !customerAddress) return;
    const randomOrder = `AET-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderNumber(randomOrder);
    setCheckoutComplete(true);
    onClearCart();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FAF8F5] shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 bg-white border-b border-[#14233C]/8 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#10223D]" />
              <h2 className="font-serif text-xl font-medium text-[#10223D]">
                Your Botanical Bag
              </h2>
              <span className="text-xs px-2 py-0.5 rounded-full bg-[#1A3F9C]/10 text-[#1A3F9C] font-semibold tabular-nums">
                {totals.itemCount}
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-[#14233C]/60 hover:text-[#10223D] rounded-lg hover:bg-black/5 transition-colors"
              aria-label="Close bag"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Meter */}
          <div className="px-6 py-3.5 bg-[#EEF2FF] border-b border-[#C7D2FE]/60">
            <div className="flex items-center justify-between text-xs text-[#1A3F9C] font-medium mb-1.5">
              <span>
                {totals.freeShippingRemaining === 0
                  ? '🎉 Complimentary Worldwide Shipping Unlocked!'
                  : `Add ${formatCurrency(totals.freeShippingRemaining)} more for Free Shipping`}
              </span>
              <span className="tabular-nums font-semibold">
                ${totals.subtotal.toFixed(0)} / ${FREE_SHIPPING_THRESHOLD}
              </span>
            </div>
            <div className="w-full h-1.5 bg-blue-200/60 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#1A3F9C] transition-all duration-500 rounded-full"
                style={{
                  width: `${Math.min(100, (totals.subtotal / FREE_SHIPPING_THRESHOLD) * 100)}%`,
                }}
              />
            </div>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {items.length === 0 ? (
              <div className="py-16 text-center text-[#14233C]/60">
                <ShoppingBag className="w-12 h-12 mx-auto text-[#14233C]/20 mb-4" />
                <p className="font-serif text-lg text-[#10223D] mb-1">Your bag is empty</p>
                <p className="text-xs max-w-xs mx-auto mb-6">
                  Explore our butterfly pea infusions and awaken your daily tea ritual.
                </p>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#10223D] hover:bg-[#1A3F9C] rounded-lg transition-colors"
                >
                  Discover Collections
                </button>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 p-3.5 bg-white rounded-xl border border-[#14233C]/8 shadow-xs"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 object-cover rounded-lg bg-[#FAF8F5] shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <h4 className="text-sm font-medium text-[#10223D] truncate pr-2">
                        {item.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="text-[#14233C]/40 hover:text-red-600 transition-colors"
                        aria-label={`Remove ${item.name}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-[11px] text-[#14233C]/60 mb-2 truncate">{item.subtitle}</p>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center border border-[#14233C]/15 rounded-md overflow-hidden bg-[#FAF8F5]">
                        <button
                          onClick={() => onUpdateQuantity(item.id, -1)}
                          className="px-2 py-1 text-xs hover:bg-black/5 text-[#10223D]"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 text-xs font-medium tabular-nums text-[#10223D]">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, 1)}
                          className="px-2 py-1 text-xs hover:bg-black/5 text-[#10223D]"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <span className="text-sm font-serif font-medium text-[#10223D] tabular-nums">
                        {formatCurrency(item.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Module */}
          {items.length > 0 && (
            <div className="p-6 bg-white border-t border-[#14233C]/8 space-y-4">
              
              {/* Promo code input */}
              <form onSubmit={applyPromo} className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Promo code (e.g. BLOOM10)"
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-200 uppercase tracking-wider placeholder:normal-case placeholder:tracking-normal focus:outline-[#1A3F9C]"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3.5 py-2 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-[#10223D] rounded-lg transition-colors"
                >
                  Apply
                </button>
              </form>

              {promoMessage && (
                <p className="text-[11px] text-[#1A3F9C] font-medium">{promoMessage}</p>
              )}

              {/* Price Calculation breakdown */}
              <div className="space-y-1.5 text-xs text-[#14233C]/75 pt-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono tabular-nums">{formatCurrency(totals.subtotal)}</span>
                </div>
                {totals.discount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-medium">
                    <span>Botanical Discount (10%)</span>
                    <span className="font-mono tabular-nums">-{formatCurrency(totals.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Estimated Shipping</span>
                  <span className="font-mono tabular-nums">
                    {totals.shipping === 0 ? 'Complimentary' : formatCurrency(totals.shipping)}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-semibold text-[#10223D] pt-2 border-t border-slate-100">
                  <span className="font-serif">Grand Total</span>
                  <span className="font-serif tabular-nums text-base">
                    {formatCurrency(totals.total)}
                  </span>
                </div>
              </div>

              {/* Primary Buy CTA */}
              <button
                onClick={() => setIsCheckoutOpen(true)}
                className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-[#10223D] hover:bg-[#1A3F9C] active:scale-[0.98] transition-all rounded-lg shadow-md focus-visible:outline-2 focus-visible:outline-[#1A3F9C]"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-[#14233C]/50">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>256-Bit Encrypted Secure Botanical Checkout</span>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Checkout Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-60 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => {
                setIsCheckoutOpen(false);
                setCheckoutComplete(false);
              }}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700"
              aria-label="Close checkout"
            >
              <X className="w-5 h-5" />
            </button>

            {checkoutComplete ? (
              <div className="text-center py-6">
                <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto mb-4" />
                <h3 className="font-serif text-2xl text-[#10223D] font-normal mb-2">
                  Order Confirmed!
                </h3>
                <p className="text-xs text-[#14233C]/70 mb-4">
                  Thank you, <span className="font-medium text-[#10223D]">{customerName}</span>. Your artisanal batch is being prepared for dispatch.
                </p>
                <div className="p-4 rounded-xl bg-[#FAF8F5] border border-slate-200 mb-6 text-left text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Order Reference:</span>
                    <span className="font-mono font-bold text-[#10223D]">{orderNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Delivery Address:</span>
                    <span className="text-[#10223D]">{customerAddress}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Total Billed:</span>
                    <span className="font-bold text-[#1A3F9C]">{formatCurrency(totals.total)}</span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setIsCheckoutOpen(false);
                    setCheckoutComplete(false);
                    onClose();
                  }}
                  className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#10223D] hover:bg-[#1A3F9C] rounded-lg transition-colors"
                >
                  Return to Storefront
                </button>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <ShoppingBag className="w-4 h-4 text-[#1A3F9C]" />
                  <span className="text-xs uppercase tracking-widest text-[#1A3F9C] font-semibold">
                    Complete Your Acquisition
                  </span>
                </div>
                <h3 className="font-serif text-2xl text-[#10223D] font-normal mb-4">
                  Delivery Details
                </h3>

                <form onSubmit={handleCheckoutSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-[#10223D] mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Eleanor Vance"
                      className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-slate-200 focus:outline-[#1A3F9C]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#10223D] mb-1">
                      Email Address (for shipment tracking)
                    </label>
                    <input
                      type="email"
                      required
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="eleanor@botanicals.com"
                      className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-slate-200 focus:outline-[#1A3F9C]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#10223D] mb-1">
                      Shipping Destination
                    </label>
                    <input
                      type="text"
                      required
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      placeholder="742 Evergreen Terrace, Portland, OR"
                      className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-slate-200 focus:outline-[#1A3F9C]"
                    />
                  </div>

                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 flex justify-between">
                    <span>Total due on dispatch</span>
                    <span className="font-bold text-[#10223D]">{formatCurrency(totals.total)}</span>
                  </div>

                  <div className="pt-2 flex gap-3">
                    <button
                      type="button"
                      onClick={() => setIsCheckoutOpen(false)}
                      className="flex-1 py-2.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#10223D] hover:bg-[#1A3F9C] rounded-lg shadow-sm transition-colors"
                    >
                      Confirm Order
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
