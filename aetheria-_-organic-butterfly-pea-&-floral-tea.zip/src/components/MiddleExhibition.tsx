import React, { useState } from 'react';
import { Eye, Plus, Check, Compass, ShieldCheck } from 'lucide-react';
import { MIDDLE_PRODUCT_IMAGE, MIDDLE_PANELS, TEA_PRODUCTS } from '../data/teaProducts';
import { CartItem, formatCurrency } from '../utils/cart';

interface MiddleExhibitionProps {
  onAddToCart: (item: CartItem) => void;
  onOpenQuickView: (productId: string) => void;
}

export const MiddleExhibition: React.FC<MiddleExhibitionProps> = ({
  onAddToCart,
  onOpenQuickView,
}) => {
  const [activeCategoryIndex, setActiveCategoryIndex] = useState(1); // Default to Imperial Gold Reserve
  const [addedId, setAddedId] = useState<string | null>(null);

  const activePanel = MIDDLE_PANELS[activeCategoryIndex];
  const activeProduct = TEA_PRODUCTS.find((p) => p.id === activePanel.associatedProductId);

  const handleAddProduct = (product: typeof activeProduct) => {
    if (!product) return;
    onAddToCart({
      id: product.id,
      name: product.name,
      subtitle: product.subtitle,
      price: product.price,
      quantity: 1,
      image: product.image,
      category: product.categoryName,
      weight: product.weight,
    });
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 2000);
  };

  const focusPercentages = ['0%', '25%', '50%', '75%', '100%'];

  return (
    <section id="the-botanical-realm" className="relative pt-24 pb-24 bg-[#10223D] text-white overflow-hidden scroll-mt-20">
      {/* Background ambient lighting reflecting active category */}
      <div
        className="absolute inset-0 opacity-30 transition-all duration-1000 pointer-events-none"
        style={{
          background: `radial-gradient(circle at ${focusPercentages[activeCategoryIndex]} 50%, ${activePanel.accentColor} 0%, transparent 60%)`,
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-10">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold mb-3">
            <Compass className="w-3.5 h-3.5" />
            <span>The Botanical Exhibition</span>
            <span aria-hidden="true">·</span>
            <span>AETHERIA Curated Realms</span>
          </div>
          <h2
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal tracking-tight text-white mb-4"
            style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
          >
            Five Expressions of Floral Alchemy
          </h2>
          <p className="text-sm sm:text-base text-white/70 leading-relaxed font-light">
            Every lineage unites single-origin <span className="text-[#D4AF37] italic">Clitoria ternatea</span> with pure complementary botanicals. 
            Crafted for distinct moments of contemplation and sensory renewal.
          </p>
        </div>

        {/* Category Parallax Control Tabs */}
        <div className="flex items-center justify-center mb-8">
          <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/15">
            {MIDDLE_PANELS.map((panel, idx) => {
              const isActive = activeCategoryIndex === idx;
              return (
                <button
                  key={panel.id}
                  onClick={() => setActiveCategoryIndex(idx)}
                  className={`px-3.5 py-2 text-xs font-medium uppercase tracking-wider rounded-lg transition-all duration-300 whitespace-nowrap shrink-0 flex items-center gap-2 ${
                    isActive
                      ? 'bg-white text-[#10223D] shadow-md font-semibold'
                      : 'text-white/75 hover:text-white hover:bg-white/5'
                  }`}
                  aria-selected={isActive}
                >
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: panel.accentColor }}
                  />
                  <span>{panel.title.split('&')[0].trim()}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Central Exhibition Stage: The Second Image with Clean Typography */}
        <div className="relative rounded-2xl overflow-hidden border border-white/20 shadow-2xl bg-black/40 group">
          
          {/* Main Panorama Image (Image 2 - The Floral Tea Product Image) */}
          <div className="relative w-full aspect-[16/9] sm:aspect-[21/9] max-h-[580px] overflow-hidden">
            <img
              src={MIDDLE_PRODUCT_IMAGE}
              alt="Five curated floral tea product categories of Aetheria: Pure Zen, Imperial Gold Reserve, Wild Harvest, Royal Amethyst, and Midnight Obsidian"
              className="w-full h-full object-cover object-center transition-all duration-700 ease-out"
              referrerPolicy="no-referrer"
            />

            {/* AETHERIA Badge */}
            <div className="absolute top-4 right-4 z-30 hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-black/60 backdrop-blur-md border border-[#D4AF37]/40 text-xs">
              <span className="font-serif text-white tracking-widest uppercase font-medium">
                AETHERIA
              </span>
              <span className="text-[#D4AF37]">· Five Botanical Realms</span>
            </div>

            {/* Interactive 5-Column Overlay Grid */}
            <div className="absolute inset-0 grid grid-cols-5 z-20">
              {MIDDLE_PANELS.map((panel, idx) => {
                const isSelected = activeCategoryIndex === idx;
                return (
                  <button
                    key={panel.id}
                    onClick={() => setActiveCategoryIndex(idx)}
                    className={`relative h-full text-left transition-all duration-300 focus-visible:outline-2 focus-visible:outline-white/80 ${
                      isSelected
                        ? 'bg-white/10 ring-2 ring-inset ring-[#D4AF37]/80'
                        : 'hover:bg-white/5 opacity-80 hover:opacity-100'
                    }`}
                    aria-label={`View ${panel.title}`}
                  >
                    {/* Top Column Number marker */}
                    <div className="absolute top-4 left-4">
                      <span
                        className={`text-[11px] font-mono px-2 py-0.5 rounded-sm backdrop-blur-md transition-all ${
                          isSelected
                            ? 'bg-[#D4AF37] text-[#10223D] font-bold'
                            : 'bg-black/50 text-white/80'
                        }`}
                      >
                        0{idx + 1}
                      </span>
                    </div>

                    {/* Bottom Column Title & Indicator */}
                    <div className="absolute bottom-4 left-3 right-3 p-2.5 rounded-lg bg-black/65 backdrop-blur-md border border-white/10 transition-all">
                      <p className="text-[10px] uppercase tracking-wider text-[#D4AF37] font-semibold truncate">
                        {panel.title}
                      </p>
                      <p className="text-[11px] text-white/80 truncate">
                        {panel.accentNotes}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Category Detail Panel (Contiguous purchase module below showcase) */}
          {activeProduct && (
            <div className="p-6 sm:p-8 bg-gradient-to-b from-[#142948] to-[#0D1B30] border-t border-white/15">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                
                {/* Column details */}
                <div className="lg:col-span-8">
                  <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-2">
                    <span>Realm 0{activeCategoryIndex + 1}</span>
                    <span aria-hidden="true">·</span>
                    <span>{activeProduct.categoryName}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-emerald-400 font-normal">100% Bleach-Free</span>
                  </div>
                  <h3
                    className="font-serif text-2xl sm:text-3xl text-white font-normal mb-2"
                    style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}
                  >
                    {activeProduct.name}
                  </h3>
                  <p className="text-sm text-white/75 leading-relaxed mb-4 max-w-2xl">
                    {activeProduct.tagline} {activePanel.description}
                  </p>

                  {/* Tasting Note Chips */}
                  <div className="flex flex-wrap items-center gap-2 text-xs text-white/85">
                    <span className="text-white/50 text-[11px] uppercase tracking-wider">Tasting Notes:</span>
                    {activeProduct.tastingNotes.map((note, nIdx) => (
                      <span
                        key={nIdx}
                        className="px-2.5 py-1 rounded-md bg-white/10 border border-white/10 text-white/90 text-xs"
                      >
                        {note}
                      </span>
                    ))}
                    <span className="px-2.5 py-1 rounded-md bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      Zero Additives
                    </span>
                  </div>
                </div>

                {/* Purchase Action Box */}
                <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col items-start lg:items-end justify-center gap-3 pt-4 lg:pt-0 border-t lg:border-t-0 border-white/10">
                  <div className="text-left lg:text-right">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl sm:text-3xl font-serif text-white font-medium tabular-nums">
                        {formatCurrency(activeProduct.price)}
                      </span>
                      {activeProduct.originalPrice && (
                        <span className="text-sm text-white/50 line-through tabular-nums">
                          {formatCurrency(activeProduct.originalPrice)}
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-white/60">Taxes included · Free shipping over $50</span>
                  </div>

                  <div className="flex items-center gap-2.5 w-full sm:w-auto">
                    <button
                      onClick={() => handleAddProduct(activeProduct)}
                      className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold tracking-wider uppercase text-[#10223D] bg-[#D4AF37] hover:bg-[#E5C378] active:scale-95 transition-all rounded-lg shadow-md focus-visible:outline-2 focus-visible:outline-white"
                    >
                      {addedId === activeProduct.id ? (
                        <>
                          <Check className="w-4 h-4 text-[#10223D]" />
                          <span>Added to Bag</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-4 h-4" />
                          <span>Add to Bag</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => onOpenQuickView(activeProduct.id)}
                      className="p-3 text-white/80 hover:text-white bg-white/10 hover:bg-white/15 border border-white/15 rounded-lg transition-colors focus-visible:outline-2 focus-visible:outline-white"
                      title="View blend details & brewing alchemy"
                      aria-label="View blend details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>

              </div>
            </div>
          )}
        </div>

        {/* Realm Navigation Footer */}
        <div className="mt-8 flex items-center justify-between text-xs text-white/60">
          <span>Click any column above to inspect each tea lineage</span>
          <span className="font-mono tabular-nums">0{activeCategoryIndex + 1} / 05</span>
        </div>

      </div>
    </section>
  );
};
