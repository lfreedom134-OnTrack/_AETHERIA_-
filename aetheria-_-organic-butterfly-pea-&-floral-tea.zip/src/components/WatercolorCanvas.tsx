import React, { useEffect, useRef } from 'react';

interface WatercolorCanvasProps {
  className?: string;
  intensity?: 'subtle' | 'vibrant';
  currentShiftColor?: string;
}

export const WatercolorCanvas: React.FC<WatercolorCanvasProps> = ({
  className = '',
  intensity = 'subtle',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const renderStaticWatercolor = () => {
      const width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
      const height = (canvas.height = canvas.parentElement?.clientHeight || window.innerHeight);

      ctx.clearRect(0, 0, width, height);

      const blobs = [
        {
          x: width * 0.22,
          y: height * 0.32,
          radius: Math.min(width, height) * 0.4,
          baseColor: [26, 63, 156], // Deep Royal Sapphire
        },
        {
          x: width * 0.78,
          y: height * 0.25,
          radius: Math.min(width, height) * 0.42,
          baseColor: [107, 63, 160], // Amethyst Violet
        },
        {
          x: width * 0.48,
          y: height * 0.68,
          radius: Math.min(width, height) * 0.45,
          baseColor: [46, 91, 184], // Butterfly Pea Cerulean
        },
        {
          x: width * 0.82,
          y: height * 0.75,
          radius: Math.min(width, height) * 0.35,
          baseColor: [212, 175, 55], // Sunlit Wildflower Gold
        },
      ];

      blobs.forEach((blob) => {
        const gradient = ctx.createRadialGradient(
          blob.x,
          blob.y,
          blob.radius * 0.08,
          blob.x,
          blob.y,
          blob.radius
        );

        const [r, g, b] = blob.baseColor;
        const alphaCenter = intensity === 'vibrant' ? 0.24 : 0.14;
        const alphaMid = intensity === 'vibrant' ? 0.12 : 0.06;

        gradient.addColorStop(0, `rgba(${r}, ${g}, ${b}, ${alphaCenter})`);
        gradient.addColorStop(0.5, `rgba(${r}, ${g}, ${b}, ${alphaMid})`);
        gradient.addColorStop(1, `rgba(${r}, ${g}, ${b}, 0)`);

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(blob.x, blob.y, blob.radius, 0, Math.PI * 2);
        ctx.fill();
      });
    };

    renderStaticWatercolor();
    window.addEventListener('resize', renderStaticWatercolor);

    return () => {
      window.removeEventListener('resize', renderStaticWatercolor);
    };
  }, [intensity]);

  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}>
      <canvas
        ref={canvasRef}
        className="w-full h-full opacity-80 blur-2xl transform scale-105 animate-watercolor-bleed"
      />
    </div>
  );
};
