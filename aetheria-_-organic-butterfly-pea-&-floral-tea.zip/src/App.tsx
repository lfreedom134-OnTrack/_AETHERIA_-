import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { PurityPromiseStrip } from './components/PurityPromiseStrip';
import { MiddleExhibition } from './components/MiddleExhibition';
import { ColorAlchemySection } from './components/ColorAlchemySection';
import { ProductCatalog } from './components/ProductCatalog';
import { BrewingRitual } from './components/BrewingRitual';
import { BotanicalSourcing } from './components/BotanicalSourcing';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { WatercolorCanvas } from './components/WatercolorCanvas';
import { CartItem } from './utils/cart';
import { HERO_IMAGE } from './data/teaProducts';

export default function App() {
  // Pre-seed cart with 1 Aetheria Signature Butterfly Pea Box
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: 'aetheria-signature-butterfly-pea',
      name: 'Aetheria Signature Butterfly Pea',
      subtitle: '20 Bleach-Free Bags · 40g',
      price: 24.0,
      quantity: 1,
      image: HERO_IMAGE,
      category: 'Signature Collection',
      weight: '40g',
    },
  ]);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [quickViewProductId, setQuickViewProductId] = useState<string | null>(null);

  const handleAddToCart = (newItem: CartItem) => {
    setCartItems((prevItems) => {
      const existing = prevItems.find((item) => item.id === newItem.id);
      if (existing) {
        return prevItems.map((item) =>
          item.id === newItem.id
            ? { ...item, quantity: item.quantity + (newItem.quantity || 1) }
            : item
        );
      }
      return [...prevItems, { ...newItem, quantity: newItem.quantity || 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prevItems) =>
      prevItems
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  return (
    <div className="relative min-h-screen bg-[#FAF8F5] text-[#14233C] selection:bg-[#1A3F9C]/20 selection:text-[#10223D]">
      {/* Ambient Watercolor Background Wash */}
      <WatercolorCanvas intensity="subtle" />

      {/* Top Bar Header (Minimalist single bar: Tea shop, Tea guide, Our brand) */}
      <Header
        cartItems={cartItems}
        onOpenCart={() => setIsCartOpen(true)}
      />

      <main>
        {/* Section 1: Hero Landing (Image 1 - The First Picture as Full-Width Immersive Banner) */}
        <Hero
          onAddToCart={handleAddToCart}
          onOpenQuickView={(id) => setQuickViewProductId(id)}
        />

        {/* Section 2: Buddha Teas-Inspired Purity & Ethics Strip */}
        <PurityPromiseStrip />

        {/* Section 3: Middle Botanical Exhibition (Image 2 - The Floral Tea Product Image with Parallax Categories) */}
        <MiddleExhibition
          onAddToCart={handleAddToCart}
          onOpenQuickView={(id) => setQuickViewProductId(id)}
        />

        {/* Section 4: Interactive Color Alchemy Lab (pH anthocyanin transformation) */}
        <ColorAlchemySection
          onAddToCart={handleAddToCart}
        />

        {/* Section 5: Full Curated Product Catalog Grid (Wellness Benefits & Single Herbs) */}
        <ProductCatalog
          onAddToCart={handleAddToCart}
          onOpenQuickView={(id) => setQuickViewProductId(id)}
        />

        {/* Section 6: The Mindful Brewing Ritual & Steep Timer */}
        <BrewingRitual />

        {/* Section 7: Ethical Sourcing & Bleach-Free Standards */}
        <BotanicalSourcing />
      </main>

      {/* Footer */}
      <Footer />

      {/* Slide-over Cart Drawer & Checkout Flow */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Quick View / Tasting Notes Modal */}
      <ProductDetailModal
        productId={quickViewProductId}
        onClose={() => setQuickViewProductId(null)}
        onAddToCart={handleAddToCart}
      />
    </div>
  );
}
