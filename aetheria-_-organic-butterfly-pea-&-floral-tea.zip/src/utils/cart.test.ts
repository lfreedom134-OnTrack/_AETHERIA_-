import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateCartTotals, calculateColorShift, formatCurrency, FREE_SHIPPING_THRESHOLD } from './cart.ts';

test('calculateCartTotals computes subtotal and items correctly', () => {
  const items = [
    {
      id: 'aetheria-signature-butterfly-pea',
      name: 'Aetheria Signature Butterfly Pea',
      subtitle: '20 Bleach-Free Bags · 40g',
      price: 24.0,
      quantity: 2,
      image: '/assets/aistudio/Gemini_Generated_Image__1__fdd46dd6.jpeg',
      category: 'Signature Collection',
      weight: '40g',
    },
    {
      id: 'aetheria-royal-amethyst-twilight',
      name: 'Aetheria Royal Amethyst Twilight',
      subtitle: 'Art Deco Geometric Elixir',
      price: 18.5,
      quantity: 1,
      image: '/assets/aistudio/Gemini_Generated_Image_a27211d7.jpeg',
      category: 'Twilight Reserve',
      weight: '45g',
    },
  ];

  const totals = calculateCartTotals(items, 0);
  assert.equal(totals.itemCount, 3);
  assert.equal(totals.subtotal, 66.5);
  assert.equal(totals.shipping, 0); // Above $50 threshold -> free shipping
  assert.equal(totals.freeShippingRemaining, 0);
  assert.equal(totals.total, 66.5);
});

test('calculateCartTotals applies standard shipping under threshold', () => {
  const items = [
    {
      id: 'aetheria-signature-butterfly-pea',
      name: 'Aetheria Signature Butterfly Pea',
      subtitle: '20 Bleach-Free Bags · 40g',
      price: 24.0,
      quantity: 1,
      image: '/assets/aistudio/Gemini_Generated_Image__1__fdd46dd6.jpeg',
      category: 'Signature Collection',
      weight: '40g',
    },
  ];

  const totals = calculateCartTotals(items, 0);
  assert.equal(totals.subtotal, 24.0);
  assert.equal(totals.shipping, 4.95);
  assert.equal(totals.freeShippingRemaining, 26.0);
  assert.equal(totals.total, 28.95);
});

test('calculateCartTotals handles promo discounts', () => {
  const items = [
    {
      id: 'item1',
      name: 'Aetheria Box',
      subtitle: 'Sub',
      price: 100.0,
      quantity: 1,
      image: '',
      category: 'Tea',
      weight: '40g',
    },
  ];

  const totals = calculateCartTotals(items, 10);
  assert.equal(totals.discount, 10.0);
  assert.equal(totals.total, 90.0);
});

test('calculateColorShift transitions correctly between pH levels', () => {
  const blue = calculateColorShift(7.5);
  assert.equal(blue.colorName, 'Royal Sapphire Blue');

  const violet = calculateColorShift(5.8);
  assert.equal(violet.colorName, 'Twilight Violet');

  const magenta = calculateColorShift(3.5);
  assert.equal(magenta.colorName, 'Vibrant Magenta Blossom');
});

test('formatCurrency formats floating numbers to USD format', () => {
  assert.equal(formatCurrency(24), '$24.00');
  assert.equal(formatCurrency(4.95), '$4.95');
});
