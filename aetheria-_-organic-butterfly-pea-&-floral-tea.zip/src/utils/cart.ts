export interface CartItem {
  id: string;
  name: string;
  subtitle: string;
  price: number;
  quantity: number;
  image: string;
  category: string;
  weight: string;
}

export interface CartTotals {
  itemCount: number;
  subtotal: number;
  discount: number;
  shipping: number;
  freeShippingThreshold: number;
  freeShippingRemaining: number;
  total: number;
}

export const FREE_SHIPPING_THRESHOLD = 50;
export const STANDARD_SHIPPING = 4.95;

export function calculateCartTotals(items: CartItem[], promoDiscountPercentage = 0): CartTotals {
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const roundedSubtotal = Math.round(subtotal * 100) / 100;
  
  const discount = Math.round(roundedSubtotal * (promoDiscountPercentage / 100) * 100) / 100;
  const subtotalAfterDiscount = Math.max(0, roundedSubtotal - discount);

  const freeShipping = roundedSubtotal >= FREE_SHIPPING_THRESHOLD || items.length === 0;
  const shipping = freeShipping ? 0 : STANDARD_SHIPPING;
  const freeShippingRemaining = Math.max(0, Math.round((FREE_SHIPPING_THRESHOLD - roundedSubtotal) * 100) / 100);

  const total = Math.round((subtotalAfterDiscount + shipping) * 100) / 100;

  return {
    itemCount,
    subtotal: roundedSubtotal,
    discount,
    shipping,
    freeShippingThreshold: FREE_SHIPPING_THRESHOLD,
    freeShippingRemaining,
    total,
  };
}

export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateColorShift(phLevel: number): {
  colorName: string;
  hexColor: string;
  glowColor: string;
  description: string;
} {
  // Butterfly pea tea (anthocyanin) color shift curve
  // pH 7.0 - 8.0: Royal Sapphire / Deep Cobalt Blue
  // pH 5.0 - 6.5: Violet / Royal Amethyst
  // pH 3.0 - 4.5: Vivid Magenta / Rose Fuchsia
  if (phLevel >= 6.8) {
    return {
      colorName: 'Royal Sapphire Blue',
      hexColor: '#1A3F9C',
      glowColor: 'rgba(26, 63, 156, 0.45)',
      description: 'Pure neutral spring infusion, rich in natural ternatins with an earthy sweet aroma.',
    };
  } else if (phLevel >= 5.2) {
    return {
      colorName: 'Twilight Violet',
      hexColor: '#6B3FA0',
      glowColor: 'rgba(107, 63, 160, 0.45)',
      description: 'First drop of citrus shifts anthocyanin molecules into a dreamy violet twilight bloom.',
    };
  } else {
    return {
      colorName: 'Vibrant Magenta Blossom',
      hexColor: '#B8236B',
      glowColor: 'rgba(184, 35, 107, 0.45)',
      description: 'High acidity unlocks crisp floral fruitiness and a stunning jewel-toned magenta hue.',
    };
  }
}
