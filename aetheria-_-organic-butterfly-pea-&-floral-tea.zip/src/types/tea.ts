export type TeaCategory = 
  | 'all'
  | 'signature'
  | 'zen'
  | 'wild'
  | 'twilight'
  | 'modernist';

export type WellnessBenefit = 
  | 'all'
  | 'sleep'
  | 'radiance'
  | 'clarity'
  | 'vitality';

export interface TeaProduct {
  id: string;
  name: string;
  subtitle: string;
  tagline: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  weight: string;
  servings: string;
  category: TeaCategory;
  categoryName: string;
  wellnessBenefit: WellnessBenefit;
  wellnessLabel: string;
  singleIngredient?: string;
  purityBadges: string[];
  image: string;
  secondaryImage?: string;
  palette: {
    primary: string;
    accent: string;
    bgTone: string;
    borderTone: string;
  };
  tasteProfile: {
    floral: number; // 0-100
    earthy: number;
    sweetness: number;
    citrusShift: number;
  };
  tastingNotes: string[];
  ingredients: string[];
  brewGuide: {
    temp: string;
    time: string;
    water: string;
    alchemyTip: string;
  };
  featuredInHero?: boolean;
  featuredInMiddle?: boolean;
  middlePanelIndex?: number;
  inStock: boolean;
}
